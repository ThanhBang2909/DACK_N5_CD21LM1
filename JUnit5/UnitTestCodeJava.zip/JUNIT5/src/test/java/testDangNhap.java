import org.testng.annotations.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class testDangNhap {
    @Test
    public  void  testDangNhap1()  {
        DangNhap dangNhap1 = new DangNhap();
        boolean result = dangNhap1.kiemTraDangNhap("phandinhhy.com", "aa123");
        assertFalse(result);
    }

    @Test
    public  void  testDangNhap2()  {
        DangNhap dangNhap2 = new DangNhap();
        boolean result = dangNhap2.kiemTraDangNhap("phandinhhy123@gmail.com", "Aa#123");
        assertTrue(result);
    }
}
