import org.testng.annotations.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class testDangKy {
    @Test
    public void testDangKy1() {
        DangKy dangKy1 = new DangKy();
        boolean result = dangKy1.kiemTraDangKy("err","tranthaodien.com", "0123", "aee", "12er");
        assertFalse(result);
    }


    @Test
    public void testDangKy2() {
        DangKy dangKy2 = new DangKy();
        boolean result = dangKy2.kiemTraDangKy("TranThaoDien","tranthaodien@gmail.com", "0123456789", "ThaoDien", "12erA@");
        assertTrue(result);
    }
}
