import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DangNhap {
    public boolean kiemTraDangNhap(String email, String password) {
        Pattern passPattern = Pattern.compile("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,}");
        Matcher passMatcher = passPattern.matcher(password);

        Pattern emailPattern = Pattern.compile("\\w+@\\w+(\\.\\w+)+(\\.\\w+)*");
        Matcher emailMatcher = emailPattern.matcher(email);

        if(email.equals(emailMatcher) && password.equals(passMatcher)) {
            return true;
        } else if(email.trim().length() != 0 || email != null) {
            return true;
        } else if (password.trim().length() != 0 || password != null) {
            return true;
        }else {
            return false;
        }
    }
}
