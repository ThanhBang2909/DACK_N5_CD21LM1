import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DangKy {
    public boolean kiemTraDangKy(String name, String email, String phoneNumber, String nameAccount, String password) {
        Pattern namePatter = Pattern.compile("  [a-z0-9_-]{6,35}$");
        Matcher nameMatcher = namePatter.matcher(name);

        Pattern emailPattern = Pattern.compile("\\w+@\\w+(\\.\\w+)+(\\.\\w+)*");
        Matcher emailMatcher = emailPattern.matcher(email);

        Pattern phoneNumberPattern = Pattern.compile("\\+84\\d{10}");
        Matcher phoneNumberMatcher = phoneNumberPattern.matcher(phoneNumber);

        Pattern nameAccountPatter = Pattern.compile("  [a-z0-9_-]{6,35}$");
        Matcher nameAccountMatcher = namePatter.matcher(nameAccount);

        Pattern passPattern = Pattern.compile("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,}");
        Matcher passMatcher = passPattern.matcher(password);

        if(name.equals(nameMatcher) && email.equals(emailMatcher) && phoneNumber.equals(phoneNumberMatcher) &&
                nameAccount.equals(nameAccountMatcher) && password.equals(passMatcher)) {
            return true;
        } else if (name.trim().length() != 0 || name != null) {
            return true;
        } else if (email.trim().length() != 0 || email != null) {
            return true;
        } else if (password.trim().length() != 0 || password != null) {
            return true;
        } else if (phoneNumber.trim().length() !=0 || phoneNumber != null) {
            return true;
        } else if (nameAccount.trim().length() != 0 || nameAccount != null) {
            return true;
        }else {
            return false;
        }
    }
}
